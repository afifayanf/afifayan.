import { useState } from "react";
import { Navbar } from "./components/layout/Navbar";
import { ParticleBackground } from "./components/layout/ParticleBackground";
import { FloatingOrbs } from "./components/layout/FloatingOrbs";
import { ScrollProgress } from "./components/layout/ScrollProgress";
import { Hero } from "./components/sections/Hero";
import { Stats } from "./components/sections/Stats";
import { Project } from "./components/sections/Project";
import { Services } from "./components/sections/Services";
import { Founder } from "./components/sections/Founder";
import { SongUploader } from "./components/sections/SongUploader";
import { Contact } from "./components/sections/Contact";
import { Footer } from "./components/layout/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-[#060810] text-white overflow-x-hidden">
      <ParticleBackground />
      <FloatingOrbs />
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <Stats />
        <Project />
        <Services />
        <Founder />
        <SongUploader />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
