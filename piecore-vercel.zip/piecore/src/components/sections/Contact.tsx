import { motion } from "framer-motion";
import { Mail, MessageSquare, Globe, Zap } from "lucide-react";

const LINKS = [
  {icon:Globe,label:"Website",val:"piecore.gg",href:"https://piecore.gg",color:"hsl(188,100%,55%)"},
  {icon:MessageSquare,label:"Discord",val:"discord.gg/piecore",href:"https://discord.gg/piecore",color:"hsl(262,83%,70%)"},
  {icon:Mail,label:"Email",val:"support@piecore.gg",href:"mailto:support@piecore.gg",color:"hsl(320,70%,70%)"},
];

export function Contact() {
  return (
    <section id="contact" className="py-32 relative z-10" aria-labelledby="contact-heading">
      <div className="container mx-auto px-6 text-center">
        <motion.div initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}} className="max-w-2xl mx-auto">
          <div className="mb-4"><span className="section-tag">07 — Contact</span></div>
          <h2 id="contact-heading" className="section-title text-white mb-6">Ready to <span className="gradient-text">Level Up</span>?</h2>
          <p className="text-white/45 text-lg leading-relaxed mb-12">Get your PieCore game server running in 60 seconds. Bangladesh's fastest game hosting, built for gamers like you.</p>
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            <a href="https://piecore.gg" target="_blank" rel="noopener noreferrer" className="btn-primary text-white rounded-sm flex items-center gap-2">
              <span className="relative z-10 flex items-center gap-2"><Zap className="w-4 h-4"/>Start Hosting Now</span>
            </a>
            <a href="https://discord.gg/piecore" target="_blank" rel="noopener noreferrer" className="btn-outline rounded-sm flex items-center gap-2">
              <MessageSquare className="w-4 h-4"/>Join Discord
            </a>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {LINKS.map((l,i)=>(
              <motion.a key={l.label} href={l.href} target="_blank" rel="noopener noreferrer"
                initial={{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.1,duration:.6}}
                className="glass rounded-2xl p-5 border border-white/8 hover:border-white/15 transition-all duration-300 group text-left"
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.boxShadow=`0 0 30px ${l.color}15`}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.boxShadow="none"}}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform" style={{background:`${l.color}15`,border:`1px solid ${l.color}25`}}>
                  <l.icon className="w-5 h-5" style={{color:l.color}}/>
                </div>
                <p className="font-mono text-xs text-white/30 tracking-wider uppercase mb-1">{l.label}</p>
                <p className="font-display font-semibold text-white text-sm">{l.val}</p>
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
