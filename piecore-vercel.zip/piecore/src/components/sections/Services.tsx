import { motion } from "framer-motion";
import { Server, Shield, Zap, Cpu, Globe, Headphones } from "lucide-react";

const PLANS = [
  { name:"Starter",price:"৳299",period:"/mo",color:"hsl(188,100%,50%)",icon:Zap,features:["2 vCPU","4GB RAM","50GB SSD","1 Gbps Port","DDoS Basic","24/7 Support"],popular:false },
  { name:"Pro",price:"৳599",period:"/mo",color:"hsl(262,83%,58%)",icon:Server,features:["4 vCPU","8GB RAM","100GB NVMe","1 Gbps Port","DDoS Advanced","Priority Support","Daily Backups"],popular:true },
  { name:"Ultra",price:"৳1199",period:"/mo",color:"hsl(320,70%,65%)",icon:Cpu,features:["8 vCPU","16GB RAM","200GB NVMe","10 Gbps Port","DDoS Enterprise","Dedicated Support","Hourly Backups","Custom Panel"],popular:false },
];

const FEATURES = [
  { icon:Shield,title:"Enterprise DDoS Protection",desc:"Multi-layer mitigation against volumetric and application-level attacks. Your server stays online no matter what.",color:"hsl(262,83%,70%)" },
  { icon:Globe,title:"Bangladesh-Optimized Network",desc:"Peered with local ISPs for the lowest possible ping for Bangladeshi players. Built for your region.",color:"hsl(188,100%,55%)" },
  { icon:Zap,title:"60-Second Deployment",desc:"Spin up your game server in under a minute. Supports Minecraft, CS2, Valheim, ARK, and 50+ games.",color:"hsl(45,100%,60%)" },
  { icon:Headphones,title:"24/7 Expert Support",desc:"Real humans who understand game servers. Bengali & English support available around the clock.",color:"hsl(320,70%,70%)" },
];

export function Services() {
  return (
    <section id="services" className="py-32 relative z-10" aria-labelledby="services-heading">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] opacity-[0.04] blur-3xl rounded-full"
          style={{background:"radial-gradient(ellipse,hsl(262,83%,58%),hsl(188,100%,50%),transparent)"}}/>
      </div>

      <div className="container mx-auto px-6">
        <motion.div initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}}>
          <div className="mb-4"><span className="section-tag">03 — Plans</span></div>
          <h2 id="services-heading" className="section-title text-white mb-4">
            Hosting <span className="gradient-text">Plans</span>
          </h2>
          <p className="text-white/40 text-lg mb-20 max-w-xl">Simple, transparent pricing built for Bangladeshi gamers. No hidden fees.</p>
        </motion.div>

        {/* Pricing cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-24">
          {PLANS.map((p,i)=>(
            <motion.div key={p.name}
              initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.12,duration:.7}}
              className={`relative glass rounded-2xl p-7 border transition-all duration-300 flex flex-col ${p.popular?"scale-[1.03]":""}`}
              style={{borderColor:p.popular?`${p.color}40`:"rgba(255,255,255,0.08)",boxShadow:p.popular?`0 0 40px ${p.color}15`:"none"}}
              onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=`${p.color}50`;el.style.boxShadow=`0 0 40px ${p.color}15,0 20px 60px rgba(0,0,0,0.3)`;el.style.transform=p.popular?"scale(1.05) translateY(-4px)":"translateY(-4px)"}}
              onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=p.popular?`${p.color}40`:"rgba(255,255,255,0.08)";el.style.boxShadow=p.popular?`0 0 40px ${p.color}15`:"none";el.style.transform=p.popular?"scale(1.03)":""}}
            >
              {p.popular&&<div className="absolute -top-3 left-1/2 -translate-x-1/2 font-mono text-xs px-4 py-1 rounded-full border font-bold" style={{background:`${p.color}20`,borderColor:`${p.color}50`,color:p.color}}>⭐ Most Popular</div>}
              <div className="absolute top-0 left-0 right-0 h-px rounded-t-2xl opacity-60" style={{background:`linear-gradient(90deg,transparent,${p.color},transparent)`}}/>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5" style={{background:`${p.color}15`,border:`1px solid ${p.color}25`}}>
                <p.icon className="w-6 h-6" style={{color:p.color}}/>
              </div>
              <div className="font-display font-bold text-white text-xl mb-1">{p.name}</div>
              <div className="mb-6">
                <span className="font-display font-bold text-4xl text-white">{p.price}</span>
                <span className="font-mono text-xs text-white/30">{p.period}</span>
              </div>
              <ul className="space-y-3 flex-1 mb-7">
                {p.features.map(f=>(
                  <li key={f} className="flex items-center gap-2.5 text-sm text-white/55">
                    <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0" style={{background:`${p.color}18`}}>
                      <div className="w-1.5 h-1.5 rounded-full" style={{background:p.color}}/>
                    </div>
                    {f}
                  </li>
                ))}
              </ul>
              <a href="https://piecore.gg" target="_blank" rel="noopener noreferrer"
                className={`w-full py-3 rounded-xl font-display font-bold text-sm text-center transition-all duration-200 ${p.popular?"text-white":"border text-white/70 hover:text-white"}`}
                style={p.popular?{background:`linear-gradient(135deg,${p.color},${p.color}bb)`,boxShadow:`0 8px 25px ${p.color}30`}:{borderColor:`${p.color}30`}}
              >
                Get Started →
              </a>
            </motion.div>
          ))}
        </div>

        {/* Feature grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map((f,i)=>(
            <motion.div key={f.title}
              initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.1,duration:.6}}
              className="glass rounded-2xl p-6 border border-white/8 hover:border-white/15 transition-all duration-300 group"
              onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.boxShadow=`0 0 30px ${f.color}12`}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.boxShadow="none"}}
            >
              <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4 transition-transform duration-200 group-hover:scale-110" style={{background:`${f.color}15`,border:`1px solid ${f.color}25`}}>
                <f.icon className="w-5 h-5" style={{color:f.color}}/>
              </div>
              <h3 className="font-display font-semibold text-white text-base mb-2">{f.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
