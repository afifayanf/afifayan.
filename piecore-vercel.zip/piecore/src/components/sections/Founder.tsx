import { motion } from "framer-motion";
import { Code2, Server, Brain, Terminal, Palette, Cpu, Zap, ChevronRight, Sparkles } from "lucide-react";

const SKILLS = [
  {label:"Full Stack Dev",Icon:Code2,color:"hsl(262,83%,70%)",acc:"hsl(262,83%,58%)"},
  {label:"VPS Infrastructure",Icon:Server,color:"hsl(188,100%,55%)",acc:"hsl(188,100%,45%)"},
  {label:"AI Integration",Icon:Brain,color:"hsl(320,70%,70%)",acc:"hsl(320,70%,55%)"},
  {label:"Linux Admin",Icon:Terminal,color:"hsl(262,83%,70%)",acc:"hsl(262,83%,58%)"},
  {label:"UI/UX Design",Icon:Palette,color:"hsl(188,100%,55%)",acc:"hsl(188,100%,45%)"},
  {label:"API Systems",Icon:Cpu,color:"hsl(320,70%,70%)",acc:"hsl(320,70%,55%)"},
  {label:"Automation",Icon:Zap,color:"hsl(262,83%,70%)",acc:"hsl(262,83%,58%)"},
];

export function Founder() {
  return (
    <section id="founder" className="py-32 relative z-10" aria-labelledby="founder-heading">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] opacity-[0.035] blur-3xl" style={{background:"radial-gradient(circle,hsl(262,83%,58%),transparent 70%)"}}/>
        <div className="absolute bottom-0 left-0 w-[350px] h-[350px] opacity-[0.025] blur-3xl" style={{background:"radial-gradient(circle,hsl(188,100%,50%),transparent 70%)"}}/>
      </div>

      <div className="container mx-auto px-6">
        <motion.div initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}}>
          <div className="mb-4"><span className="section-tag">05 — Founder</span></div>
          <h2 id="founder-heading" className="section-title text-white mb-4">About the <span className="gradient-text">Founder</span></h2>
          <p className="text-white/40 text-lg mb-20 max-w-xl">The architect behind PieCore and CrynoGpt.</p>
        </motion.div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-16 items-start">
          <motion.div initial={{opacity:0,x:-40}} whileInView={{opacity:1,x:0}} viewport={{once:true}} transition={{duration:.8}} className="space-y-8">
            {/* Card */}
            <div className="glass rounded-2xl p-8 border border-white/8 hover:border-purple-500/20 transition-colors duration-500 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 opacity-10 pointer-events-none" style={{background:"radial-gradient(circle at top right,hsl(262,83%,58%),transparent 70%)"}}/>
              <div className="flex items-start gap-5">
                <div className="relative flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden border border-purple-500/30" style={{boxShadow:"0 0 25px hsl(262,83%,58%,0.3)"}}>
                    <img src="/profile.png" alt="CrynoXDevs Leader" className="w-full h-full object-cover object-top"
                      onError={e=>{const t=e.currentTarget;t.style.display="none";const d=t.parentElement!;d.style.background="linear-gradient(135deg,hsl(262,83%,25%),hsl(188,100%,12%))";d.style.display="flex";d.style.alignItems="center";d.style.justifyContent="center";d.innerHTML='<span style="font-size:26px;font-weight:900;background:linear-gradient(135deg,hsl(262,83%,75%),hsl(188,100%,60%));-webkit-background-clip:text;-webkit-text-fill-color:transparent">C</span>';}}
                    />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-green-400 border-2 border-[#060810]" style={{boxShadow:"0 0 8px rgba(74,222,128,0.6)"}}/>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1"><Sparkles className="w-4 h-4 text-purple-400"/><span className="font-mono text-xs text-purple-400/70 tracking-widest uppercase">Founder</span></div>
                  <h3 className="font-display font-bold text-2xl text-white mb-1">CrynoXDevs Leader</h3>
                  <p className="font-mono text-sm text-purple-400/80">Owner & Founder of CrynoGpt</p>
                </div>
              </div>
              <div className="mt-6 pt-6 border-t border-white/5">
                <p className="text-white/55 leading-relaxed">Passionate full-stack developer, infrastructure engineer, and AI enthusiast focused on building modern hosting platforms, automation systems, AI tools, and scalable cloud solutions. Specialized in frontend systems, backend APIs, VPS infrastructure, Linux server management, and modern UI/UX experiences.</p>
              </div>
            </div>

            {/* Exp badge */}
            <div className="inline-flex items-center gap-4 glass rounded-2xl px-7 py-5 border border-purple-500/20 hover:border-purple-500/35 transition-colors" style={{boxShadow:"0 0 40px hsl(262,83%,58%,0.07)"}}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.2),hsl(188,100%,50%,0.1))",border:"1px solid hsl(262,83%,58%,0.3)",boxShadow:"0 0 20px hsl(262,83%,58%,0.15)"}}>
                <Zap className="w-6 h-6 text-purple-400"/>
              </div>
              <div>
                <div className="font-display font-bold text-4xl text-white">2<span className="gradient-text">+</span></div>
                <div className="font-mono text-xs text-white/30 tracking-widest uppercase">Years Experience</div>
              </div>
            </div>

            {/* Skills */}
            <div>
              <p className="font-mono text-xs text-white/20 tracking-widest uppercase mb-5">Core Expertise</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SKILLS.map((s,i)=>(
                  <motion.div key={s.label}
                    initial={{opacity:0,x:-20}} whileInView={{opacity:1,x:0}} viewport={{once:true}} transition={{delay:i*.06,duration:.5}}
                    className="group flex items-center gap-3 rounded-xl px-4 py-3 border border-white/5 cursor-default transition-all duration-300"
                    style={{background:"rgba(255,255,255,0.02)"}}
                    onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=`${s.acc}35`;el.style.boxShadow=`0 0 20px ${s.acc}12`}}
                    onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor="rgba(255,255,255,0.05)";el.style.boxShadow="none"}}
                  >
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-transform duration-200 group-hover:scale-110" style={{background:`${s.color}18`,border:`1px solid ${s.color}28`}}>
                      <s.Icon className="w-4 h-4" style={{color:s.color}}/>
                    </div>
                    <span className="text-sm text-white/55 group-hover:text-white/85 transition-colors font-medium">{s.label}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-white/10 group-hover:text-white/30 ml-auto transition-colors"/>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Profile image */}
          <motion.div initial={{opacity:0,x:40}} whileInView={{opacity:1,x:0}} viewport={{once:true}} transition={{duration:.8,delay:.15}} className="relative lg:sticky lg:top-28">
            <div className="absolute -inset-4 rounded-3xl opacity-50 blur-2xl" style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.35),hsl(320,70%,65%,0.2),hsl(188,100%,50%,0.2))",animation:"glowPulse 4s ease-in-out infinite"}}/>
            <div className="relative rounded-2xl p-[1px]" style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.6),hsl(320,70%,65%,0.4),hsl(188,100%,50%,0.5))"}}>
              <div className="rounded-2xl overflow-hidden relative">
                <img src="/profile.png" alt="CrynoXDevs Leader — Founder of PieCore & CrynoGpt" className="w-full object-cover object-top" style={{aspectRatio:"4/5"}} loading="lazy" decoding="async"
                  onError={e=>{const t=e.currentTarget;const p=t.parentElement!;t.style.display="none";p.style.background="linear-gradient(135deg,hsl(262,83%,15%),hsl(188,100%,8%))";p.style.aspectRatio="4/5";p.style.display="flex";p.style.alignItems="center";p.style.justifyContent="center";p.innerHTML='<div style="text-align:center"><div style="font-size:80px;font-weight:900;background:linear-gradient(135deg,hsl(262,83%,75%),hsl(188,100%,60%));-webkit-background-clip:text;-webkit-text-fill-color:transparent">C</div><div style="color:rgba(255,255,255,0.3);font-size:12px;font-family:monospace;margin-top:8px">CrynoXDevs</div></div>';}}
                />
                <div className="absolute inset-0 pointer-events-none" style={{background:"linear-gradient(to top,rgba(6,8,16,0.7) 0%,rgba(6,8,16,0.15) 40%,transparent 70%)"}}/>
                <div className="absolute inset-0 opacity-[0.025] pointer-events-none" style={{backgroundImage:"repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(139,92,246,0.8) 3px,rgba(139,92,246,0.8) 4px)",backgroundSize:"100% 4px"}}/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="glass rounded-xl px-4 py-3 border border-purple-500/25" style={{boxShadow:"0 0 25px hsl(262,83%,58%,0.18),0 8px 32px rgba(0,0,0,0.4)"}}>
                    <p className="font-display font-semibold text-sm text-white">CrynoXDevs Leader</p>
                    <p className="gradient-text font-mono text-xs mt-0.5">Owner & Founder of CrynoGpt</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -top-3 -right-3 w-6 h-6 rounded-full blur-sm opacity-65" style={{background:"hsl(188,100%,50%)"}}/>
            <div className="absolute -bottom-3 -left-3 w-8 h-8 rounded-full blur-md opacity-55" style={{background:"hsl(262,83%,58%)"}}/>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
