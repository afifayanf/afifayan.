import { motion } from "framer-motion";
import { Server, Users, Zap, Shield } from "lucide-react";

const STATS = [
  { icon: Server, val: "500+", label: "Servers Deployed", color: "hsl(262,83%,70%)" },
  { icon: Users,  val: "1200+", label: "Happy Gamers",    color: "hsl(188,100%,55%)" },
  { icon: Zap,    val: "<5ms",  label: "Avg Latency",     color: "hsl(320,70%,70%)" },
  { icon: Shield, val: "99.9%", label: "Uptime SLA",      color: "hsl(45,100%,60%)" },
];

export function Stats() {
  return (
    <section className="py-16 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="glass rounded-2xl p-6 border border-white/8 hover:border-white/15 transition-all duration-300 text-center group relative overflow-hidden cursor-default"
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 0 30px ${s.color}18`; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
            >
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{ background: `radial-gradient(circle at center, ${s.color}08, transparent 70%)` }}/>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200"
                style={{ background: `${s.color}15`, border: `1px solid ${s.color}25` }}>
                <s.icon className="w-6 h-6" style={{ color: s.color }}/>
              </div>
              <div className="font-display font-bold text-3xl text-white mb-1">{s.val}</div>
              <div className="font-mono text-xs text-white/35 tracking-wider uppercase">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
