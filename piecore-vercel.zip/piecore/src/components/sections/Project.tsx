import { motion } from "framer-motion";
import { ExternalLink, MessageSquare, Phone, Star, Zap, Server } from "lucide-react";

const TAGS = ["React","Node.js","MongoDB","TailwindCSS","Express.js","Cloudflare","WebSockets","Redis"];

export function Project() {
  return (
    <section id="project" className="py-32 relative z-10" aria-labelledby="project-heading">
      <div className="container mx-auto px-6">
        <motion.div initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}}>
          <div className="mb-4"><span className="section-tag">02 — Platform</span></div>
          <h2 id="project-heading" className="section-title text-white mb-4">
            Our <span className="gradient-text">Platform</span>
          </h2>
          <p className="text-white/40 text-lg mb-20 max-w-xl">
            Bangladesh's most advanced game server hosting — engineered for zero-lag competitive play.
          </p>
        </motion.div>

        <motion.article
          initial={{opacity:0,y:60}} whileInView={{opacity:1,y:0}}
          viewport={{once:true,margin:"-80px"}} transition={{duration:.9,ease:[.16,1,.3,1]}}
          className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center"
        >
          {/* Image */}
          <div className="relative group">
            <div className="absolute -inset-3 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-xl"
              style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.4),hsl(188,100%,50%,0.25))"}}/>
            <div className="relative glass rounded-2xl overflow-hidden border border-white/8 group-hover:border-purple-500/30 transition-colors duration-500"
              style={{boxShadow:"0 30px 80px -20px rgba(0,0,0,0.8)"}}>
              {/* Browser chrome */}
              <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/5" style={{background:"rgba(0,0,0,0.5)"}}>
                <div className="w-3 h-3 rounded-full bg-red-500/60"/>
                <div className="w-3 h-3 rounded-full bg-yellow-500/60"/>
                <div className="w-3 h-3 rounded-full bg-green-500/60"/>
                <div className="flex-1 mx-4 h-5 rounded bg-white/5 flex items-center px-3 gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400/50 flex-shrink-0"/>
                  <span className="font-mono text-[10px] text-white/25 truncate">piecore.gg</span>
                </div>
              </div>
              <div className="relative overflow-hidden" style={{aspectRatio:"16/9"}}>
                <img
                  src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85"
                  alt="PieCore — Game server datacenter infrastructure"
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-[1.04]"
                  loading="lazy" decoding="async"
                />
                {/* PieCore logo overlay on image */}
                <div className="absolute inset-0" style={{background:"linear-gradient(135deg,rgba(88,28,220,0.5) 0%,transparent 50%,rgba(0,230,255,0.2) 100%)"}}/>
                <div className="absolute inset-0" style={{background:"linear-gradient(to top,rgba(6,8,16,.7) 0%,transparent 40%)"}}/>
                {/* Scanlines */}
                <div className="absolute inset-0 opacity-[0.025] pointer-events-none"
                  style={{backgroundImage:"repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,255,255,0.5) 2px,rgba(255,255,255,0.5) 3px)",backgroundSize:"100% 3px"}}/>
                {/* Live badge */}
                <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="glass rounded-lg px-3 py-1.5 flex items-center gap-2 border border-green-500/30"
                    style={{boxShadow:"0 0 15px rgba(34,197,94,0.2)"}}>
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"/>
                    <span className="font-mono text-[10px] text-green-400">LIVE</span>
                  </div>
                </div>
                {/* PieCore logo chip */}
                <div className="absolute bottom-3 left-3">
                  <div className="glass rounded-xl px-3 py-2 flex items-center gap-2 border border-purple-500/30"
                    style={{boxShadow:"0 0 20px hsl(262,83%,58%,0.25)"}}>
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{background:"linear-gradient(135deg,hsl(262,83%,58%),hsl(188,100%,45%))"}}>
                      <Zap className="w-3.5 h-3.5 text-white"/>
                    </div>
                    <span className="font-display font-bold text-xs gradient-text">PieCore</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-7">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="flex items-center gap-1.5 font-mono text-xs text-yellow-400 border border-yellow-400/25 bg-yellow-400/5 px-3 py-1 rounded-full"
                style={{boxShadow:"0 0 12px rgba(250,204,21,0.1)"}}>
                <Star className="w-3 h-3 fill-yellow-400"/> ⭐ Featured
              </span>
              <span className="flex items-center gap-1.5 font-mono text-xs text-purple-400/70 border border-purple-500/20 px-3 py-1 rounded-full">
                <Zap className="w-3 h-3"/> 2024
              </span>
              <span className="font-mono text-xs text-green-400/60 border border-green-500/20 px-3 py-1 rounded-full flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"/> Online
              </span>
            </div>

            <div>
              <h3 className="font-display font-bold text-4xl md:text-5xl text-white mb-3 leading-tight">PieCore</h3>
              <p className="text-sm font-mono text-purple-400/70 mb-4">Bangladesh's Best Game Server Hosting</p>
              <p className="text-white/50 text-base leading-relaxed">
                Bangladesh's premium game server hosting platform powered by CrynoXDevs. Built with high-performance infrastructure, DDoS protection, real-time monitoring, instant deployment automation, and ultra-fast network routing optimized for South Asian latency.
              </p>
            </div>

            {/* Feature highlights */}
            <div className="grid grid-cols-2 gap-3">
              {[
                {icon:"⚡",label:"&lt;5ms Latency"},
                {icon:"🛡️",label:"DDoS Shield"},
                {icon:"🎮",label:"Game Optimized"},
                {icon:"🔄",label:"Auto Backups"},
              ].map(f=>(
                <div key={f.label} className="glass rounded-xl px-3 py-2.5 flex items-center gap-2.5 border border-white/5 hover:border-purple-500/20 transition-colors">
                  <span className="text-base">{f.icon}</span>
                  <span className="font-mono text-xs text-white/55" dangerouslySetInnerHTML={{__html:f.label}}/>
                </div>
              ))}
            </div>

            <div>
              <p className="font-mono text-xs text-white/20 tracking-widest uppercase mb-3">Tech Stack</p>
              <div className="flex flex-wrap gap-2">
                {TAGS.map(t=><span key={t} className="tag-chip hover:border-purple-500/50 hover:bg-purple-500/15 transition-all duration-200">{t}</span>)}
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-1">
              <a href="https://piecore.gg" target="_blank" rel="noopener noreferrer" className="btn-primary text-white rounded-sm text-xs flex items-center gap-2">
                <span className="relative z-10 flex items-center gap-2"><ExternalLink className="w-3.5 h-3.5"/> Visit PieCore</span>
              </a>
              <a href="https://discord.gg/piecore" target="_blank" rel="noopener noreferrer" className="btn-outline rounded-sm text-xs flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5"/> Discord
              </a>
              <a href="mailto:support@piecore.gg" className="btn-outline rounded-sm text-xs flex items-center gap-2" style={{borderColor:"hsl(320,70%,65%,0.5)",color:"hsl(320,70%,75%)"}}>
                <Phone className="w-3.5 h-3.5"/> Contact
              </a>
            </div>
          </div>
        </motion.article>
      </div>
    </section>
  );
}
