import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowDown, Zap, Shield, Globe, Server } from "lucide-react";

const ROLES = ["Bangladesh's #1 Game Host","Ultra-Low Latency Servers","99.9% Uptime Guaranteed","DDoS Protected 24/7","Built for Bangladeshi Gamers"];

function Typewriter({ words }: { words: string[] }) {
  const [wi,setWi]=useState(0); const [ci,setCi]=useState(0); const [del,setDel]=useState(false);
  useEffect(()=>{
    const w=words[wi]??""; const delay=del?40:ci===w.length?1800:80;
    const t=setTimeout(()=>{
      if(!del&&ci<w.length)setCi(c=>c+1);
      else if(!del&&ci===w.length)setDel(true);
      else if(del&&ci>0)setCi(c=>c-1);
      else{setDel(false);setWi(w=>(w+1)%words.length);}
    },delay); return()=>clearTimeout(t);
  },[wi,ci,del,words]);
  return <span className="gradient-text">{(words[wi]??"").slice(0,ci)}<span className="animate-blink text-purple-400">|</span></span>;
}

const FLOAT_CARDS = [
  {icon:Shield,label:"DDoS Protection",val:"24/7",top:"18%",left:"5%",delay:0,color:"hsl(262,83%,58%)"},
  {icon:Globe,label:"Network Uptime",val:"99.9%",top:"15%",right:"5%",delay:1,color:"hsl(188,100%,50%)"},
  {icon:Server,label:"Avg Latency",val:"<5ms",bottom:"22%",left:"3%",delay:2,color:"hsl(320,70%,65%)"},
  {icon:Zap,label:"Setup Time",val:"60sec",bottom:"20%",right:"5%",delay:1.5,color:"hsl(45,100%,60%)"},
];

export function Hero() {
  return (
    <section id="hero" className="relative min-h-[100dvh] flex items-center pt-24 pb-12 overflow-hidden">
      {/* Scan line sweep */}
      <div className="absolute inset-x-0 h-px pointer-events-none z-0 animate-glow-pulse" style={{top:"50%",background:"linear-gradient(90deg,transparent,hsl(262,83%,58%,0.15),transparent)",animationDuration:"4s"}}/>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-[1fr_500px] gap-16 items-center">
          {/* Left */}
          <div className="flex flex-col gap-7">
            <motion.div initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{delay:.1}}>
              <span className="section-tag flex items-center gap-2">
                <span className="w-8 h-px" style={{background:"hsl(262,83%,58%)"}}/>
                Bangladesh's Best Game Hosting
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse ml-1"/>
              </span>
            </motion.div>

            <motion.div initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} transition={{delay:.2,duration:.7}}>
              <h1 className="section-title text-white leading-tight">
                Power Your<br/>
                <span className="gradient-text">Game Server</span><br/>
                With <span style={{background:"linear-gradient(135deg,hsl(320,70%,75%),hsl(262,83%,75%))",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text"}}>PieCore</span>
              </h1>
            </motion.div>

            <motion.p className="text-xl text-white/55 h-8" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:.35}}>
              <Typewriter words={ROLES}/>
            </motion.p>

            <motion.p className="text-base md:text-lg text-white/45 max-w-xl leading-relaxed" initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:.45}}>
              PieCore delivers premium game server infrastructure powered by CrynoXDevs — built specifically for Bangladeshi gamers who demand the best. Zero lag, maximum uptime, instant deployment.
            </motion.p>

            <motion.div className="flex flex-wrap gap-4 mt-2" initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:.55}}>
              <a href="https://piecore.gg" target="_blank" rel="noopener noreferrer" className="btn-primary text-white rounded-sm flex items-center gap-2">
                <span className="relative z-10 flex items-center gap-2"><Zap className="w-4 h-4"/>Start Hosting →</span>
              </a>
              <a href="#services" className="btn-outline rounded-sm flex items-center gap-2">View Plans</a>
            </motion.div>

            {/* Trust badges */}
            <motion.div className="flex flex-wrap items-center gap-4 mt-2" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:.7}}>
              {["🇧🇩 Bangladesh Local","⚡ Instant Deploy","🔒 DDoS Shield","🎮 Game Optimized"].map(b=>(
                <span key={b} className="font-mono text-[11px] text-white/35 border border-white/8 px-3 py-1 rounded-full">{b}</span>
              ))}
            </motion.div>
          </div>

          {/* Right – server visual */}
          <motion.div className="relative flex items-center justify-center" initial={{opacity:0,scale:.85}} animate={{opacity:1,scale:1}} transition={{duration:.9,type:"spring",bounce:.3,delay:.2}}>
            {/* Floating stat cards */}
            {FLOAT_CARDS.map((c,i)=>(
              <motion.div key={i}
                className="absolute glass rounded-xl px-3 py-2.5 border border-white/8 z-20 hidden md:flex items-center gap-2.5"
                style={{top:c.top,bottom:(c as any).bottom,left:(c as any).left,right:(c as any).right,boxShadow:`0 0 20px ${c.color}20`}}
                animate={{y:[0,-8,0]}} transition={{duration:3+i*.5,repeat:Infinity,ease:"easeInOut",delay:i*.7}}
              >
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{background:`${c.color}18`,border:`1px solid ${c.color}30`}}>
                  <c.icon className="w-3.5 h-3.5" style={{color:c.color}}/>
                </div>
                <div>
                  <div className="font-display font-bold text-sm text-white leading-none">{c.val}</div>
                  <div className="font-mono text-[9px] text-white/35 mt-0.5">{c.label}</div>
                </div>
              </motion.div>
            ))}

            {/* Central server rack visual */}
            <div className="relative w-72 md:w-[340px]">
              {/* Outer glow rings */}
              <div className="absolute -inset-6 rounded-2xl border border-purple-500/15 animate-border-glow"/>
              <div className="absolute -inset-12 rounded-2xl border border-cyan-500/8 animate-glow-pulse"/>

              {/* Glow blob */}
              <div className="absolute inset-0 rounded-2xl blur-2xl opacity-50" style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.4),hsl(188,100%,50%,0.2))"}}/>

              {/* Image */}
              <div className="relative rounded-2xl overflow-hidden border border-white/10" style={{boxShadow:"0 30px 80px -10px rgba(0,0,0,0.8)"}}>
                <img src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=85" alt="PieCore game server infrastructure" className="w-full object-cover" style={{aspectRatio:"3/4"}} loading="eager"/>
                <div className="absolute inset-0" style={{background:"linear-gradient(135deg,hsl(262,83%,58%,0.45) 0%,transparent 50%,hsl(188,100%,50%,0.2) 100%)"}}/>
                <div className="absolute inset-0" style={{background:"linear-gradient(to top,rgba(6,8,16,.75) 0%,transparent 50%)"}}/>
                {/* PieCore logo overlay */}
                <div className="absolute top-4 left-4 flex items-center gap-2 glass rounded-xl px-3 py-2 border border-purple-500/30" style={{boxShadow:"0 0 15px hsl(262,83%,58%,0.3)"}}>
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{background:"linear-gradient(135deg,hsl(262,83%,58%),hsl(188,100%,45%))"}}>
                    <Zap className="w-3.5 h-3.5 text-white"/>
                  </div>
                  <span className="font-display font-bold text-xs gradient-text">PieCore</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll hint */}
      <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/20" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:1.5}}>
        <span className="font-mono text-[9px] tracking-[.4em] uppercase">Scroll</span>
        <motion.div animate={{y:[0,8,0]}} transition={{duration:1.5,repeat:Infinity}}><ArrowDown className="w-4 h-4"/></motion.div>
      </motion.div>
    </section>
  );
}
