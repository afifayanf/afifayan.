export function FloatingOrbs() {
  const orbs = [
    { w:600,h:600,top:"10%",left:"60%",color:"hsl(262,83%,58%)",op:0.07,dur:"20s",delay:"0s" },
    { w:450,h:450,top:"55%",left:"5%",color:"hsl(188,100%,50%)",op:0.055,dur:"26s",delay:"-8s" },
    { w:350,h:350,top:"30%",left:"40%",color:"hsl(320,70%,60%)",op:0.04,dur:"17s",delay:"-4s" },
    { w:280,h:280,top:"75%",left:"75%",color:"hsl(262,83%,58%)",op:0.05,dur:"22s",delay:"-12s" },
    { w:200,h:200,top:"15%",left:"20%",color:"hsl(188,100%,50%)",op:0.06,dur:"14s",delay:"-6s" },
  ];
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {orbs.map((o,i)=>(
        <div key={i} className="absolute rounded-full" style={{
          width:o.w,height:o.h,top:o.top,left:o.left,
          background:`radial-gradient(circle,${o.color},transparent 70%)`,
          opacity:o.op,filter:"blur(60px)",
          animation:`orbDrift ${o.dur} ease-in-out infinite`,
          animationDelay:o.delay,transform:"translate(-50%,-50%)"
        }}/>
      ))}
      {/* Horizontal neon lines */}
      {[15,40,70].map((top,i)=>(
        <div key={`line-${i}`} className="absolute left-0 right-0 animate-glow-pulse" style={{
          top:`${top}%`,height:"1px",
          background:`linear-gradient(90deg,transparent,hsl(${i===1?188:262},83%,${i===1?50:58}%,0.12),transparent)`,
          animationDelay:`${i*1.2}s`
        }}/>
      ))}
    </div>
  );
}
