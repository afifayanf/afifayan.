import { Zap } from "lucide-react";
export function Footer() {
  return (
    <footer className="border-t border-white/5 py-10">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{background:"linear-gradient(135deg,hsl(262,83%,58%),hsl(188,100%,45%))"}}>
            <Zap className="w-4 h-4 text-white"/>
          </div>
          <span className="font-display font-bold gradient-text">PieCore</span>
        </div>
        <p className="font-mono text-xs text-white/20 text-center">© 2024 PieCore · Powered by CrynoXDevs · Bangladesh 🇧🇩</p>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"/>
          <span className="font-mono text-xs text-white/30">All systems operational</span>
        </div>
      </div>
    </footer>
  );
}
