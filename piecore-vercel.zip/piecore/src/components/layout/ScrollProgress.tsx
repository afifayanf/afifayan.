import { useEffect, useState } from "react";
export function ScrollProgress() {
  const [pct,setPct]=useState(0);
  useEffect(()=>{
    const fn=()=>{ const el=document.documentElement; setPct(el.scrollTop/(el.scrollHeight-el.clientHeight)*100); };
    window.addEventListener("scroll",fn,{passive:true});
    return()=>window.removeEventListener("scroll",fn);
  },[]);
  return <div className="fixed top-0 left-0 right-0 z-[200] h-[2px]" style={{background:"rgba(255,255,255,0.03)"}}>
    <div className="h-full transition-all duration-100" style={{width:`${pct}%`,background:"linear-gradient(90deg,hsl(262,83%,58%),hsl(188,100%,50%),hsl(320,70%,65%))",boxShadow:"0 0 10px hsl(262,83%,58%,0.5)"}}/>
  </div>;
}
