import { useEffect, useRef } from "react";

interface Particle { x:number;y:number;vx:number;vy:number;alpha:number;r:number;hue:number;pulse:number;pulseSpeed:number }

export function ParticleBackground() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current; if(!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let animId=0, w=0, h=0;
    const resize=()=>{ w=canvas.width=window.innerWidth; h=canvas.height=window.innerHeight; };
    resize(); window.addEventListener("resize",resize);
    const ps: Particle[] = Array.from({length:55},()=>({
      x:Math.random()*window.innerWidth, y:Math.random()*window.innerHeight,
      vx:(Math.random()-.5)*.25, vy:(Math.random()-.5)*.25,
      alpha:Math.random()*.4+.05, r:Math.random()*1.8+.4,
      hue:Math.random()<.6?262:188, pulse:0, pulseSpeed:Math.random()*.04+.02
    }));
    const draw=()=>{
      ctx.clearRect(0,0,w,h);
      for(const p of ps){
        p.x+=p.vx; p.y+=p.vy; p.pulse+=p.pulseSpeed;
        if(p.x<0)p.x=w; if(p.x>w)p.x=0;
        if(p.y<0)p.y=h; if(p.y>h)p.y=0;
        const a=p.alpha*(0.7+0.3*Math.sin(p.pulse));
        ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
        ctx.fillStyle=`hsla(${p.hue},83%,70%,${a})`; ctx.fill();
      }
      for(let i=0;i<ps.length;i++) for(let j=i+1;j<ps.length;j++){
        const dx=ps[i]!.x-ps[j]!.x, dy=ps[i]!.y-ps[j]!.y, d=Math.hypot(dx,dy);
        if(d<130){ ctx.beginPath(); ctx.moveTo(ps[i]!.x,ps[i]!.y); ctx.lineTo(ps[j]!.x,ps[j]!.y);
          ctx.strokeStyle=`rgba(139,92,246,${.07*(1-d/130)})`; ctx.lineWidth=.5; ctx.stroke(); }
      }
      animId=requestAnimationFrame(draw);
    };
    draw();
    return()=>{ cancelAnimationFrame(animId); window.removeEventListener("resize",resize); };
  },[]);
  return <canvas ref={ref} className="fixed inset-0 pointer-events-none z-0" style={{opacity:.7}}/>;
}
